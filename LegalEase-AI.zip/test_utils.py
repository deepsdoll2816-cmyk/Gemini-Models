from backend.utils.text_utils import *


def test_text_utils_module():
    assert True