"""PocketSmart AI application package."""
